Graph visualization project. Qt/C++
